import React from 'react'
import '../../Home.css'
import Hero from './Hero'
import Popular from './Popular'
import Database from './Database'
import Footer from '../footerr'




function Home() {
  return (
    <>
<Hero/>
<Popular/>
<Database/>


  </>
  
  )
}

export default Home
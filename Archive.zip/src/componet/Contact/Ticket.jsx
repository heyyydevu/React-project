// import React from 'react'
// import { Container } from 'react-bootstrap'

// function Ticket() {
//   return (
//     <div className="main-ticket">
//         <Container>
//         <div className="upper">
//             <div className="det-cont">
//                 <h5>PRICES</h5>
//                 <h1>OUR TICKETS</h1>
//             </div>


           

//         </div>
//         </Container>

//     </div>
//   )
// }

// export default Ticket